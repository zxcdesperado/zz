from ptp_cli import *

def main():
    main_cli()

if __name__ == "__main__":
    main()